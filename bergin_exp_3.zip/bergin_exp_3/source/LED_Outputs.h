#ifndef _LED_Outputs_H
#define _LED_Outputs_H

#include "Main.H"


// LED Output Functions


void LEDS_ON(uint8_t LED_bits);
void LEDS_OFF(uint8_t LED_bits);



#endif